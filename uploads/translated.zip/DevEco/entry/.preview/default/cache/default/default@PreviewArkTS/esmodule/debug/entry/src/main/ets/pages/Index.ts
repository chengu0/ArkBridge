if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Page2_Params {
    area?: number[][];
    directions?: 'up' | 'down' | 'left' | 'right';
    tryDirections?: 'up' | 'down' | 'left' | 'right';
    historyPosition?: number[][];
    headX?: number;
    headY?: number;
    length?: number;
    colors?: ResourceColor[];
    end?: string;
}
class Page2 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__area = new ObservedPropertyObjectPU([]
        // 当前运动方向
        , this, "area");
        this.__directions = new ObservedPropertySimplePU('right'
        // 控制方向
        , this, "directions");
        this.__tryDirections = new ObservedPropertySimplePU('right'
        // 历史位置 用于蛇移动时更新蛇头和蛇尾
        , this, "tryDirections");
        this.__historyPosition = new ObservedPropertyObjectPU([]
        // 头部坐标
        , this, "historyPosition");
        this.__headX = new ObservedPropertySimplePU(0, this, "headX");
        this.__headY = new ObservedPropertySimplePU(0
        // 蛇的长度
        , this, "headY");
        this.__length = new ObservedPropertySimplePU(0
        // 颜色 不同的表示渲染不同等等颜色
        , this, "length");
        this.__colors = new ObservedPropertyObjectPU([Color.Black, Color.Black, Color.Orange]
        //结束提示
        , this, "colors");
        this.__end = new ObservedPropertySimplePU(''
        // 初始化
        , this, "end");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Page2_Params) {
        if (params.area !== undefined) {
            this.area = params.area;
        }
        if (params.directions !== undefined) {
            this.directions = params.directions;
        }
        if (params.tryDirections !== undefined) {
            this.tryDirections = params.tryDirections;
        }
        if (params.historyPosition !== undefined) {
            this.historyPosition = params.historyPosition;
        }
        if (params.headX !== undefined) {
            this.headX = params.headX;
        }
        if (params.headY !== undefined) {
            this.headY = params.headY;
        }
        if (params.length !== undefined) {
            this.length = params.length;
        }
        if (params.colors !== undefined) {
            this.colors = params.colors;
        }
        if (params.end !== undefined) {
            this.end = params.end;
        }
    }
    updateStateVars(params: Page2_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__area.purgeDependencyOnElmtId(rmElmtId);
        this.__directions.purgeDependencyOnElmtId(rmElmtId);
        this.__tryDirections.purgeDependencyOnElmtId(rmElmtId);
        this.__historyPosition.purgeDependencyOnElmtId(rmElmtId);
        this.__headX.purgeDependencyOnElmtId(rmElmtId);
        this.__headY.purgeDependencyOnElmtId(rmElmtId);
        this.__length.purgeDependencyOnElmtId(rmElmtId);
        this.__colors.purgeDependencyOnElmtId(rmElmtId);
        this.__end.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__area.aboutToBeDeleted();
        this.__directions.aboutToBeDeleted();
        this.__tryDirections.aboutToBeDeleted();
        this.__historyPosition.aboutToBeDeleted();
        this.__headX.aboutToBeDeleted();
        this.__headY.aboutToBeDeleted();
        this.__length.aboutToBeDeleted();
        this.__colors.aboutToBeDeleted();
        this.__end.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 二维数组 表示运动区域
    private __area: ObservedPropertyObjectPU<number[][]>;
    get area() {
        return this.__area.get();
    }
    set area(newValue: number[][]) {
        this.__area.set(newValue);
    }
    // 当前运动方向
    private __directions: ObservedPropertySimplePU<'up' | 'down' | 'left' | 'right'>;
    get directions() {
        return this.__directions.get();
    }
    set directions(newValue: 'up' | 'down' | 'left' | 'right') {
        this.__directions.set(newValue);
    }
    // 控制方向
    private __tryDirections: ObservedPropertySimplePU<'up' | 'down' | 'left' | 'right'>;
    get tryDirections() {
        return this.__tryDirections.get();
    }
    set tryDirections(newValue: 'up' | 'down' | 'left' | 'right') {
        this.__tryDirections.set(newValue);
    }
    // 历史位置 用于蛇移动时更新蛇头和蛇尾
    private __historyPosition: ObservedPropertyObjectPU<number[][]>;
    get historyPosition() {
        return this.__historyPosition.get();
    }
    set historyPosition(newValue: number[][]) {
        this.__historyPosition.set(newValue);
    }
    // 头部坐标
    private __headX: ObservedPropertySimplePU<number>;
    get headX() {
        return this.__headX.get();
    }
    set headX(newValue: number) {
        this.__headX.set(newValue);
    }
    private __headY: ObservedPropertySimplePU<number>;
    get headY() {
        return this.__headY.get();
    }
    set headY(newValue: number) {
        this.__headY.set(newValue);
    }
    // 蛇的长度
    private __length: ObservedPropertySimplePU<number>;
    get length() {
        return this.__length.get();
    }
    set length(newValue: number) {
        this.__length.set(newValue);
    }
    // 颜色 不同的表示渲染不同等等颜色
    private __colors: ObservedPropertyObjectPU<ResourceColor[]>;
    get colors() {
        return this.__colors.get();
    }
    set colors(newValue: ResourceColor[]) {
        this.__colors.set(newValue);
    }
    //结束提示
    private __end: ObservedPropertySimplePU<string>;
    get end() {
        return this.__end.get();
    }
    set end(newValue: string) {
        this.__end.set(newValue);
    }
    // 初始化
    initArea() {
        // 25 * 25 初始化地图
        this.area = [];
        for (let i = 0; i < 25; i++) {
            this.area.push([]);
            for (let j = 0; j < 25; j++) {
                this.area[i].push(0);
            }
        }
        // 对蛇初始化
        this.area[4][6] = 1;
        //this.area[4][7]=1
        //this.area[4][8]=1
        //this.area[4][9]=1
        //this.area[4][10]=1
        // 初始化历史位置
        this.historyPosition = [];
        this.historyPosition.push([6, 4]);
        //this.historyPosition.push([7,4])
        //this.historyPosition.push([8,4])
        //this.historyPosition.push([9,4])
        //this.historyPosition.push([10,4])
        // 初始化头部位置
        this.headX = 10;
        this.headY = 4;
        // 初始化蛇的长度
        this.length = 1;
        // 初始化 结束提示
        this.end = '';
        // 初始化方向以及想尝试的方向 为右
        this.directions = 'right';
        this.tryDirections = 'right';
    }
    aboutToAppear(): void {
        // 初始化
        this.initArea();
        // 随机生成能量的位置
        let foodX: number = Math.floor(Math.random() * this.area[0].length);
        let foodY: number = Math.floor(Math.random() * this.area[0].length);
        // 控制蛇的移动(更新坐标)
        setInterval(() => {
            // 游戏结束后不做操作
            if (!this.end) {
                //  上一个还没吃到 或 蛇的长度占满全屏 不用生成
                if (this.area[foodY][foodX] != 2 && this.length < 25 * 25) {
                    while (true) {
                        // 生成的随机坐标为0时即为空位置时才生成能量退出循环
                        if (this.area[foodY][foodX] == 0) {
                            this.area[foodY][foodX] = 2;
                            break;
                        }
                        // 继续生成
                        foodX = Math.floor(Math.random() * this.area[0].length);
                        foodY = Math.floor(Math.random() * this.area[0].length);
                    }
                }
                // 移动后头部的新位置
                let newHeadY: number;
                let newHeadX: number;
                // 当控制方向和当前移动的方向满足条件时 才改变当前位置 避免蛇头往身后走
                if (this.tryDirections == 'right' && this.directions != 'left')
                    this.directions = 'right';
                else if (this.tryDirections == 'left' && this.directions != 'right')
                    this.directions = 'left';
                else if (this.tryDirections == 'up' && this.directions != 'down')
                    this.directions = 'up';
                else if (this.tryDirections == 'down' && this.directions != 'up')
                    this.directions = 'down';
                // 不同的方向更新不同的头部
                if (this.directions == 'right') {
                    newHeadY = this.headY;
                    newHeadX = this.headX + 1;
                }
                else if (this.directions == 'up') {
                    newHeadY = this.headY - 1;
                    newHeadX = this.headX;
                }
                else if (this.directions == 'down') {
                    newHeadY = this.headY + 1;
                    newHeadX = this.headX;
                }
                else {
                    newHeadY = this.headY;
                    newHeadX = this.headX - 1;
                }
                // 判断是否撞墙
                if (newHeadY >= 0 && newHeadY < this.area.length && newHeadX >= 0 && newHeadX < this.area[0].length) {
                    // 未撞墙
                    // 头部撞到自己
                    if (this.area[newHeadY][newHeadX] == 1) {
                        this.end = '吃到自己了 游戏结束！';
                    } // 未撞到
                    else {
                        // 是否吃到能量
                        let eat: boolean = false;
                        // 如果头碰到2 则视为吃到能量
                        if (this.area[newHeadY][newHeadX] == 2)
                            eat = true;
                        // 将头的位置放入历史位置中
                        this.historyPosition.push([newHeadX, newHeadY]);
                        // 获取头部的那一行
                        let newRowHead = this.area[newHeadY];
                        // 将头部的位置置为1 即变为蛇的一部分
                        newRowHead[newHeadX] = 1;
                        // 更新蛇头的位置
                        this.headY = newHeadY;
                        this.headX = newHeadX;
                        // 更新蛇头的那一行
                        this.area.splice(newHeadY, 1, newRowHead);
                        // 吃到了能量 无需更新尾巴 长度加一
                        if (!eat) {
                            // 没吃到能量 更新尾巴的那一行
                            // 获取尾巴的位置
                            let tailX = this.historyPosition[0][0];
                            let tailY = this.historyPosition[0][1];
                            // 移除尾巴
                            this.historyPosition.shift();
                            // 获取旧的尾巴的那一行
                            let pastRowTail = this.area[tailY];
                            // 将旧尾巴的位置置为0 表示尾巴移动
                            pastRowTail[tailX] = 0;
                            // 更新旧的尾巴的那一行
                            this.area.splice(tailY, 1, pastRowTail);
                        }
                        else {
                            // 吃到了 长度加一即可
                            this.length++;
                        }
                    }
                } //跑出边界 即为撞墙
                else
                    this.end = '游戏结束！';
            }
        }, 100); //200ms动一次
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(157:5)", "entry");
            Column.height('100%');
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(158:7)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 区域
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(160:9)", "entry");
            // 区域
            Column.borderWidth(2);
            // 区域
            Column.borderColor(Color.Orange);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 遍历每一行
            ForEach.create();
            const forEachItemGenFunction = (_item, indexR: number) => {
                const itemR = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(163:13)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 遍历每行的每一个位置
                    ForEach.create();
                    const forEachItemGenFunction = (_item, indexC: number) => {
                        const itemC = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.create(indexR == this.headY && indexC == this.headX ? '·' : '');
                            Text.debugLine("entry/src/main/ets/pages/Index.ets(167:17)", "entry");
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.textAlign(TextAlign.Center);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.fontSize(12);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.fontWeight(900);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.fontColor(Color.White);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.width(12);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.aspectRatio(1);
                            // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                            Text.backgroundColor(this.historyPosition[this.historyPosition.length - 1][0] == indexC &&
                                this.historyPosition[this.historyPosition.length - 1][1] == indexR ?
                                Color.Pink : this.colors[this.area[indexR][indexC]]);
                        }, Text);
                        // 对每一个位置进行渲染 0:空位置 1:蛇的部位 2:能量 以及是否为蛇头
                        Text.pop();
                    };
                    this.forEachUpdateFunction(elmtId, itemR, forEachItemGenFunction, undefined, true, false);
                }, ForEach);
                // 遍历每行的每一个位置
                ForEach.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.area, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        // 遍历每一行
        ForEach.pop();
        // 区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 结束时展示提示
            Column.create({ space: 10 });
            Column.debugLine("entry/src/main/ets/pages/Index.ets(184:9)", "entry");
            // 结束时展示提示
            Column.zIndex(this.end ? 1 : -1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.end);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(185:11)", "entry");
            Text.fontSize(20);
            Text.fontColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.end ? '重新开始' : '');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(188:11)", "entry");
            Text.fontSize(22);
            Text.fontColor(Color.Red);
            Text.onClick(() => {
                this.initArea();
            });
        }, Text);
        Text.pop();
        // 结束时展示提示
        Column.pop();
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 控制键
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(198:7)", "entry");
            // 控制键
            Stack.enabled(this.end ? false : true);
            // 控制键
            Stack.width('45%');
            // 控制键
            Stack.aspectRatio(1);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.createWithLabel('W');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(200:9)", "entry");
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.fontSize(20);
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.height(50);
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.width(80);
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.position({ top: 0, left: '50%' });
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.translate({ x: '-50%' });
            // 上、下、左、右 逻辑一样   以"上"操作为例
            Button.onClick(() => {
                this.tryDirections = 'up';
            });
        }, Button);
        // 上、下、左、右 逻辑一样   以"上"操作为例
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('S');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(209:9)", "entry");
            Button.fontSize(20);
            Button.height(50);
            Button.width(80);
            Button.position({ bottom: 0, left: '50%' });
            Button.translate({ x: '-50%' });
            Button.onClick(() => {
                this.tryDirections = 'down';
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('A');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(218:9)", "entry");
            Button.fontSize(20);
            Button.height(50);
            Button.width(70);
            Button.position({ left: 0, top: '50%' });
            Button.translate({ y: '-50%' });
            Button.offset({ left: 0 });
            Button.onClick(() => {
                this.tryDirections = 'left';
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('D');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(228:9)", "entry");
            Button.fontSize(20);
            Button.height(50);
            Button.width(70);
            Button.position({ right: 0, top: '50%' });
            Button.translate({ y: '-50%' });
            Button.onClick(() => {
                this.tryDirections = 'right';
            });
        }, Button);
        Button.pop();
        // 控制键
        Stack.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Page2";
    }
}
registerNamedRoute(() => new Page2(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
